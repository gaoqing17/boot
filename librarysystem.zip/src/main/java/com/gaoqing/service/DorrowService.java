package com.gaoqing.service;

import com.gaoqing.pojo.Dorrow;

import java.util.List;

public interface DorrowService {
    //借阅表，添加借阅人
    int GoTobooks(Dorrow dorrow);

    List<Dorrow> FocusSelect();
}
