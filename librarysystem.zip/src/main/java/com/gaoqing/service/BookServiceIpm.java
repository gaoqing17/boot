package com.gaoqing.service;

import com.gaoqing.dao.bookListMapper;
import com.gaoqing.pojo.booklist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BookServiceIpm implements BookService {
    @Autowired
    bookListMapper bookListMapper;

    @Override
    public List<booklist> bookselShow() {
        List<booklist> booklists = bookListMapper.bookselShow();
        return booklists;
    }

    @Override
    public int bookinsert(booklist books) {
        int bookinsert = bookListMapper.bookinsert(books);
        return bookinsert;
    }

    @Override
    public int bookdelete(int id) {
        int bookdelete = bookListMapper.bookdelete(id);
        return bookdelete;
    }

    @Override
    public booklist Toupdete(int id) {
        booklist toupdete = bookListMapper.Toupdete(id);
        return toupdete;
    }

    @Override
    public int bookupdate(booklist booKs) {
        int bookupdate = bookListMapper.bookupdate(booKs);
        return bookupdate;
    }

    @Override
    public booklist goToupdete(int id) {
        booklist booklist = bookListMapper.goToupdete(id);
        return booklist;
    }

    @Override
    public booklist bookPrice(int id) {
        return bookListMapper.bookPrice(id);
    }

}
