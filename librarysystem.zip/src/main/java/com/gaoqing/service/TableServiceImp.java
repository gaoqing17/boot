package com.gaoqing.service;

import com.gaoqing.dao.userTableMapper;
import com.gaoqing.pojo.userTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;

@Service
public class TableServiceImp implements TableService {
    @Autowired
    userTableMapper userTableMapper;
//    添加用户
    @Override
    public int addTabel(userTable userTable) {
            return userTableMapper.addTabel(userTable);
    }
//显示用户信息
    @Override
    public List<userTable> selShow() {
        List<userTable> selShow = userTableMapper.selShow();
        return selShow;
    }
//删除用户
    @Override
    public int Deletepa(int id) {
        return userTableMapper.Deletepa(id);
    }

//显示需要下的用户
    @Override
    public userTable lisTuserna(int id) {
        return userTableMapper.lisTuserna(id);
    }


    //更改用户
    @Override
    public int toinSert(userTable userTable) {
        return userTableMapper.toinSert(userTable);
    }
    //根据id搜索用户
    @Override
    public userTable Search(int id) {
        return userTableMapper.Search(id);
    }




}
