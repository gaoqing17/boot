package com.gaoqing.service;

import com.gaoqing.dao.DorrowMapper;
import com.gaoqing.pojo.Dorrow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DorrowServiceImp implements DorrowService {
    @Autowired
    DorrowMapper dorrowMapper;

    @Override
    public int GoTobooks(Dorrow dorrow) {
        return  dorrowMapper.GoTobooks(dorrow);
    }

    @Override
    public List<Dorrow> FocusSelect() {
        return dorrowMapper.FocusSelect();
    }
}
