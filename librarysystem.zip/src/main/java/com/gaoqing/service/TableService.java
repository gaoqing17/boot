package com.gaoqing.service;

import com.gaoqing.pojo.userTable;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TableService {
//   增加用户
    int addTabel(userTable userTable);
//  显示用户信息
    List<userTable> selShow();
//  删除用户
    int Deletepa(int id);
//  根据用户id修改用户
    int toinSert(userTable userTable);

//   根据用户id查询用户
    userTable lisTuserna(@Param("id") int id);

    //根据用户id搜索用户
    userTable Search(@Param("id") int id);
}
