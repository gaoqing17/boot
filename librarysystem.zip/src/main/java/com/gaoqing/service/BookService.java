package com.gaoqing.service;

import com.gaoqing.pojo.booklist;
import org.apache.ibatis.annotations.Param;


import java.util.List;

public interface BookService {
    //显示图书信息1
    List<booklist> bookselShow();

    //添加用户
    int bookinsert(booklist books);

    //根据id删除用户
    int bookdelete(@Param("id") int id);

    //    根据id查询需要修改的用户
    booklist Toupdete(@Param("id") int id);

    //修改图书信息
    int bookupdate(booklist booKs);

    // 获取书本id然后借书
    booklist goToupdete(@Param("id") int id);


    //    根据id查询书本价格
    booklist bookPrice(@Param("id")int id);
}
