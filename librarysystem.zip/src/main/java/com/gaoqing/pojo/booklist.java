package com.gaoqing.pojo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;


@ApiModel("图书表")
public class booklist {
    @ApiModelProperty("书本编号")
    private int id;
    @ApiModelProperty("书本名")
    private String bookName;
    @ApiModelProperty("作者名")
    private String author;
    @ApiModelProperty("出版社")
    private String publishing;
    @ApiModelProperty("价格")
    private int price;
    @ApiModelProperty("库存")
    private int stock;
    @ApiModelProperty("书本介绍")
    private String introduce;
    @ApiModelProperty("书本类别 1 科学类 2教育类 3 经济类 4军事类 5儿童童话")
    private int category;
    @ApiModelProperty("书本封面")
    private String cover;
    @ApiModelProperty("创建时间")
    private String creationTime;
    @ApiModelProperty("修改时间")
    private Date reviseTime;
    @ApiModelProperty("书本状态")
    private  int state;

    public booklist(int id, String bookName, String author, String publishing, int price, int stock, String introduce, int category, String cover, String creationTime, Date reviseTime, int state) {
        this.id = id;
        this.bookName = bookName;
        this.author = author;
        this.publishing = publishing;
        this.price = price;
        this.stock = stock;
        this.introduce = introduce;
        this.category = category;
        this.cover = cover;
        this.creationTime = creationTime;
        this.reviseTime = reviseTime;
        this.state = state;
    }

    public booklist(int id, String bookName, String author, String publishing, int price) {
        this.id = id;
        this.bookName = bookName;
        this.author = author;
        this.publishing = publishing;
        this.price = price;
    }

    public booklist() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublishing() {
        return publishing;
    }

    public void setPublishing(String publishing) {
        this.publishing = publishing;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getIntroduce() {
        return introduce;
    }

    public void setIntroduce(String introduce) {
        this.introduce = introduce;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(String creationTime) {
        this.creationTime = creationTime;
    }

    public Date getReviseTime() {
        return reviseTime;
    }

    public void setReviseTime(Date reviseTime) {
        this.reviseTime = reviseTime;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "booklist{" +
                "id=" + id +
                ", bookName='" + bookName + '\'' +
                ", author='" + author + '\'' +
                ", publishing='" + publishing + '\'' +
                ", price='" + price + '\'' +
                ", stock=" + stock +
                ", introduce='" + introduce + '\'' +
                ", category=" + category +
                ", cover='" + cover + '\'' +
                ", creationTime=" + creationTime +
                ", reviseTime=" + reviseTime +
                ", state=" + state +
                '}';
    }
}
