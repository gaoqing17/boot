package com.gaoqing.pojo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;



@ApiModel("借阅表")
public class Dorrow {
    @ApiModelProperty("图书id")
    private int userid;
    @ApiModelProperty("用户借书")
    private int fullname;
    @ApiModelProperty("图书编号")
    private int book_name;
    @ApiModelProperty("id")
    private int id;
    @ApiModelProperty("借出时间")
    private Date creation_time;
    @ApiModelProperty("归还时间")
    private String return_time;
    @ApiModelProperty("借书天数")
    private int specifictime;
    @ApiModelProperty("租金")
    private int payment;

    @Override
    public String toString() {
        return "Dorrow{" +
                "userid=" + userid +
                ", fullname=" + fullname +
                ", book_name=" + book_name +
                ", id=" + id +
                ", creation_time=" + creation_time +
                ", return_time='" + return_time + '\'' +
                ", specifictime=" + specifictime +
                ", payment=" + payment +
                '}';
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getFullname() {
        return fullname;
    }

    public void setFullname(int fullname) {
        this.fullname = fullname;
    }

    public int getBook_name() {
        return book_name;
    }

    public void setBook_name(int book_name) {
        this.book_name = book_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getCreation_time() {
        return creation_time;
    }

    public void setCreation_time(Date creation_time) {
        this.creation_time = creation_time;
    }

    public String getReturn_time() {
        return return_time;
    }

    public void setReturn_time(String return_time) {
        this.return_time = return_time;
    }

    public int getSpecifictime() {
        return specifictime;
    }

    public void setSpecifictime(int specifictime) {
        this.specifictime = specifictime;
    }

    public int getPayment() {
        return payment;
    }

    public void setPayment(int payment) {
        this.payment = payment;
    }

    public Dorrow(int userid, int fullname, int book_name, int id, Date creation_time, String return_time, int specifictime, int payment) {
        this.userid = userid;
        this.fullname = fullname;
        this.book_name = book_name;
        this.id = id;
        this.creation_time = creation_time;
        this.return_time = return_time;
        this.specifictime = specifictime;
        this.payment = payment;
    }

    public Dorrow() {
    }
}
