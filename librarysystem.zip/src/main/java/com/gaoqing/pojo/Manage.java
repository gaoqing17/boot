package com.gaoqing.pojo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.util.Date;

//管理员表
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("管理员表")
public class Manage {
    @ApiModelProperty("账号id")
    private int id;
    @ApiModelProperty("管理员账号")
    private String username;
    @ApiModelProperty("管理员密码")
    private String pass;
    @ApiModelProperty("账号状态 1为正常 2为冻结")
    private int account;
    @ApiModelProperty("管理员权限 1为最低 3为最高")
    private String authority;
    @ApiModelProperty("创建时间")
    private Date creationTime;
    @ApiModelProperty("修改时间")
    private Date reviseTime;

}
