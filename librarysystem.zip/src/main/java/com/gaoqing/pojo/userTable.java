package com.gaoqing.pojo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

//用户表


@ApiModel("用户表")
public class userTable {
    @ApiModelProperty("借书证号")
    private int id;
    @ApiModelProperty("用户账号")
    private String username;
    @ApiModelProperty("密码")
    private String passwor;
    @ApiModelProperty("用户姓名")
    private String fullname;
    @ApiModelProperty("性别 1 男 0 女")
    private Integer sex;
    @ApiModelProperty("借书量")
    private int borrowed;
    @ApiModelProperty("头像")
    private String avatar;
    @ApiModelProperty("账号状态 1为正常 2为冻结")
    private int accountStatus;
    @ApiModelProperty("创建时间")
    private String creationtime;
    @ApiModelProperty("修改时间")
    private Date reviseTime;

    public userTable(int id, String username, String passwor, String fullname, Integer sex, int borrowed, String avatar, int accountStatus, String creationtime, Date reviseTime) {
        this.id = id;
        this.username = username;
        this.passwor = passwor;
        this.fullname = fullname;
        this.sex = sex;
        this.borrowed = borrowed;
        this.avatar = avatar;
        this.accountStatus = accountStatus;
        this.creationtime = creationtime;
        this.reviseTime = reviseTime;
    }

    public userTable() {
    }

    public userTable(int id, String passwor, String fullname, Integer sex, int borrowed,String avatar,int accountStatus) {
        this.id = id;
        this.passwor = passwor;
        this.fullname = fullname;
        this.sex = sex;
        this.borrowed = borrowed;
        this.avatar = avatar;
        this.accountStatus = accountStatus;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswor() {
        return passwor;
    }

    public void setPasswor(String passwor) {
        this.passwor = passwor;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public int getBorrowed() {
        return borrowed;
    }

    public void setBorrowed(int borrowed) {
        this.borrowed = borrowed;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(int accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getCreationtime() {
        return creationtime;
    }

    public void setCreationtime(String creationtime) {
        this.creationtime = creationtime;
    }

    public Date getReviseTime() {
        return reviseTime;
    }

    public void setReviseTime(Date reviseTime) {
        this.reviseTime = reviseTime;
    }

    @Override
    public String toString() {
        return "userTable{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", passwor='" + passwor + '\'' +
                ", fullname='" + fullname + '\'' +
                ", sex=" + sex +
                ", borrowed=" + borrowed +
                ", avatar='" + avatar + '\'' +
                ", accountStatus=" + accountStatus +
                ", creationtime='" + creationtime + '\'' +
                ", reviseTime=" + reviseTime +
                '}';
    }
}
