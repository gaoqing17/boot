package com.gaoqing.cofig;

import org.springframework.context.annotation.Bean;
import springfox.documentation.RequestHandler;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import java.util.ArrayList;

public class SwaggerConfig {
    @Bean
    public Docket docket(){
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .enable(true)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.gaoqing.controller"))
                .build();
    }
    private ApiInfo apiInfo(){  //作者信息
        Contact contact = new Contact("高庆", "https://www.cnblogs.com/gaoqingyy/", "1300610479@qq.com");
        return new ApiInfo(
                "幻协的个人文档",
                        "人生如逆旅，我亦是行人",
                        "V1.0",
                        "https://www.cnblogs.com/gaoqingyy/",
                contact,
                "Apache 2.0",
                        "http://www.apache.org/licenses/LICENSE-2.0",
                        new ArrayList<>());
    }
}
