package com.gaoqing.cofig;


import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;



@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {

        auth.inMemoryAuthentication().passwordEncoder(new BCryptPasswordEncoder())
                .withUser("root").password(new BCryptPasswordEncoder()
                .encode("root")).roles("vip1", "vip2", "vip3")
                .and()
                .withUser("admin").password(new BCryptPasswordEncoder()
                .encode("1234")).roles("vip1")
                .and()
                .withUser("sout").password(new BCryptPasswordEncoder()
                .encode("123")).roles("vip1", "vip2");

    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable();//关闭csrf防护
        http.authorizeRequests()
                .antMatchers("/").permitAll()
                .antMatchers("/views/**").hasRole("vip1")
                .antMatchers("/adminstrator/**").hasRole("vip2");
        http.authorizeRequests()//设置那些路径可以直接访问，不需要认证
                .antMatchers("/css/**", "/js/**","/images/**", "/webjars/**", "**/favicon.ico", "/index").permitAll() // 设置哪些路径可以直接访问，不需要认证
                .anyRequest().authenticated()//其他所有请求都需要先验证才能访问
                .and()
                .formLogin()//自定义自己编写的登录页面
                .loginPage("/test/tologin") // 登录页面设置
                .loginProcessingUrl("/user/login") // 登录访问路径
                .usernameParameter("username")
                .passwordParameter("pass")
                .defaultSuccessUrl("/test/index").permitAll()// 登录成功后的跳转路径
                .failureUrl("/test/nologin")//登录失败
                .and()
                .logout().logoutSuccessUrl("/test/tologin")
                .and()
                .rememberMe().rememberMeParameter("remember");//开启记住我


    }





}
