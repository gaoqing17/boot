package com.gaoqing.cofig;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

public class ToMyMvcConfig implements WebMvcConfigurer {

    //上传地址
    @Value("${file.upload.path1}")
    private String filePath;

    //显示相对地址
    @Value("${file.upload.path.relative1}")
    private String fileRelativePath;

    /**
     * 资源映射路径
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(fileRelativePath).addResourceLocations("file:/" + filePath);
    }
}
