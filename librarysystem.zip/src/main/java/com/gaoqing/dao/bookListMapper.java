package com.gaoqing.dao;

import com.gaoqing.pojo.booklist;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface bookListMapper {
    //显示用户
    List<booklist> bookselShow();

    //添加用户
    int bookinsert(booklist books);

    //根据id删除用户
    int bookdelete(@Param("id") int id);

//    根据id查询需要修改的图书
    booklist Toupdete(@Param("id") int id);

    //修改图书信息
    int bookupdate(booklist booKs);

//根据id借阅书籍
    booklist goToupdete(@Param("id") int id);

//    根据id查询书本价格
    booklist bookPrice(@Param("id")int id);

}
