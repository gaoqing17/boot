package com.gaoqing.dao;

import com.gaoqing.pojo.Dorrow;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component
public interface DorrowMapper {
    //借阅表，添加借阅人
    int GoTobooks(Dorrow dorrow);

    List<Dorrow> FocusSelect();
}
