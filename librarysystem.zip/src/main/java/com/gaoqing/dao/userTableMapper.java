package com.gaoqing.dao;

import com.gaoqing.pojo.userTable;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface userTableMapper {
    //增加用户
    int addTabel(userTable userTable);

    //显示用户
    List<userTable> selShow();

    //根据用户id删除用户
    int Deletepa(@Param("id") int id);

    //显示需要修改的用户信息
    userTable lisTuserna(@Param("id") int id);

    //根据用户id修改用户
    int toinSert(userTable userTable);

    //根据用户id搜索用户
    userTable Search(@Param("id") int id);





}
