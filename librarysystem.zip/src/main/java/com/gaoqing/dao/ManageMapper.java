package com.gaoqing.dao;

//import com.gaoqing.pojo.Manage;
import com.gaoqing.pojo.Manage;
import org.springframework.stereotype.Repository;

@Repository
public interface ManageMapper {
//    public Manage getmanage(String usernaem);
}
