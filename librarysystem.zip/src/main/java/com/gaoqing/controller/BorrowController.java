package com.gaoqing.controller;

import com.gaoqing.pojo.Dorrow;
import com.gaoqing.pojo.booklist;
import com.gaoqing.service.BookService;
//import com.gaoqing.service.DorrowService;
import com.gaoqing.service.DorrowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Collection;


@Controller
public class BorrowController {
    @Autowired
    BookService bookService;
    @Autowired
    DorrowService dorrowService;
    @GetMapping("/borrow/{id}")
    public String ToBorrow(@PathVariable("id") int id, Model model){

        booklist bookupdet = bookService.goToupdete(id);
        Collection<booklist> booklists = bookService.bookselShow();
        System.out.println(bookupdet.getId());
        model.addAttribute("Tobookupdet",bookupdet);
        return "views/toinset/insertBorrow";
    }


//    @PostMapping("/Tobooks/{id}")
//    public String GoTobooks(@PathVariable("id") int id  ,Dorrow dorrow1,int specifictime){
//
//        booklist booklist = bookService.bookPrice(id);
//        System.out.println(booklist.getPrice());
//        dorrow1.setPayment(specifictime*booklist.getPrice());
//
//        Dorrow dorrow = new Dorrow(dorrow1.getBorrowId(),dorrow1.getBookId(),
//                dorrow1.getReturnTime(),dorrow1.getSpecifictime(),dorrow1.getPayment());
//
//        dorrowService.GoTobooks(dorrow);
//        return "views/index";
//    }
}
