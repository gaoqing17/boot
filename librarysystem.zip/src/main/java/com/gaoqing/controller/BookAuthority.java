package com.gaoqing.controller;




import com.gaoqing.pojo.userTable;
import com.gaoqing.service.TableService;
import io.swagger.annotations.ApiModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

@ApiModel("用户模块后台功能")
@Controller
public class BookAuthority {
    @Autowired
    TableService tableService;
    @Value("${file.upload.path}")
    private String filePath;

    //用户显示
    @GetMapping("/golistbook")
    public String Tolistbook(Model model) {
        Collection<userTable> userTabl = tableService.selShow();
        System.out.println(userTabl);
        model.addAttribute("usertable",userTabl);
        return "views/toselect/listuser";
    }
    //添加用户
    @GetMapping("/Toaddreaderlmfo")
    public String GOaddreaderlmfo(){
        return "views/toinset/addreaderlmfo";
    }
    //往数据库中加入数据
    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    public String upload(userTable userTable){
            tableService.addTabel(userTable);
            return "redirect:/golistbook";
    }

//    删除用户
    @GetMapping("/todelete/{id}")
    public String Deletepa(@PathVariable("id") int id){
        tableService.Deletepa(id);
        return "redirect:/golistbook";
    }

    //修改用户信息
    @GetMapping("/updatlo/{id}")
    public String Toupdate(@PathVariable("id") Integer id, Model model){
        userTable userTable = tableService.lisTuserna(id);
        Collection<userTable> collect = tableService.selShow();
        System.out.println(collect);
        model.addAttribute("tousa",userTable);
        return "views/toupdet/updatereaderlmfo";
    }


    @PostMapping(value = "/winupdate")
    public String update(@RequestParam("file") MultipartFile file,userTable userTable,Model model){


        userTable userTable1 = new userTable(userTable.getId(),userTable.getPasswor(),userTable.getFullname(),
                userTable.getSex(),userTable.getBorrowed(),userTable.getAvatar(),userTable.getAccountStatus());
        System.out.println("接收到的图片信息：");

        // 获取上传文件名
        String filename = file.getOriginalFilename();
        //选择上传本地文件，picture中picUrl='',需要将文件地址插入picUrl
        if (!"".equals(filename)){
            // 定义上传文件保存路径
            //String path = "F:\\java\\workspace\\spring-boot-04-web-restfulcrud\\src\\main\\resources\\static\\asserts\\img";
            String path = filePath;
            // 新建文件
            File filepath = new File(path, filename);
            // 判断路径是否存在，如果不存在就创建一个
            if (!filepath.getParentFile().exists()) {
                filepath.getParentFile().mkdirs();
            }
            try {
                // 写入文件
                file.transferTo(new File(path + File.separator + filename));
            } catch (IOException e) {
                e.printStackTrace();
            }
            //保存用于前端显示的picUrl
            //String picUrl = "http://localhost:8081/seller/asserts/img/" + filename;
            String picUrl = filename;
            userTable1.setAvatar(picUrl);
        }
        System.out.println(userTable1);
        tableService.toinSert(userTable1);
        return "redirect:/golistbook";
    }

    //    搜索用户
    @GetMapping("/search")
    public String Search(@RequestParam Integer id,Model model){

            userTable userTable = tableService.Search(id);
            Collection<userTable> collect = tableService.selShow();
            model.addAttribute("tousa",userTable);
            return "views/toselect/listsearchuser";

    }
}
