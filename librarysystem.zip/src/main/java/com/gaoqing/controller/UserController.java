package com.gaoqing.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/test")
public class UserController {


    //登录信息处理
    @GetMapping("/"+"/tologin")
    public String tolog(){
        return "login";
    }

    @RequestMapping("/index")
    @PreAuthorize("hasRole('vip1')")
    public String index(){

        return "views/index";
    }

    //登录失败需要返回的页面
    @RequestMapping("/nologin")
    public String loginError(Model model) {
            model.addAttribute("msg","账号或密码错误");
            return "login";
    }

}
