package com.gaoqing.controller;

import com.gaoqing.pojo.booklist;
import com.gaoqing.service.BookService;
import io.swagger.annotations.ApiModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

@ApiModel("图书模块后台功能")
@Controller
public class BookController {
    @Autowired
    BookService bookService;
    @Value("${file.upload.path1}")
    private String filePath;
    //图书库存
    @GetMapping("/inventory")
    public String Toinventory(){
        return "views/toselect/listentory";
    }


    //联系官方
    @GetMapping("/cooperate")
    public String Tocooperate(){
        return "views/toselect/cooperate";
    }

    //管理员信息
    @GetMapping("/userlnfo")
    public String Touserlnfo(){
        return "views/toselect/listAuser";
    }

    //作者信息
    @GetMapping("/author")
    public String Toauthor(){
        return "views/toselect/listauthor";
    }

    //显示所有图书
    @GetMapping("/checkall")
    public String Tocheckall(Model model){
        Collection<booklist> booklist = bookService.bookselShow();
        model.addAttribute("booklist", booklist);
        return "views/toselect/listbook";
    }

    //添加图书
    @GetMapping("/goaddbook")
    public String Toaddbook(){
        return "views/toinset/Addto";
    }

    @RequestMapping(value = "/toinset",method = RequestMethod.POST)
    public String addbook(@RequestParam("file") MultipartFile file, booklist books){
        // 获取上传文件名
        String filename = file.getOriginalFilename();
        //选择上传本地文件，picture中picUrl='',需要将文件地址插入picUrl
        if (!"".equals(filename)){
            // 定义上传文件保存路径
            String path = filePath;
            // 新建文件
            File filepath = new File(path, filename);
            // 判断路径是否存在，如果不存在就创建一个
            if (!filepath.getParentFile().exists()) {
                filepath.getParentFile().mkdirs();
            }
            try {
                // 写入文件
                file.transferTo(new File(path + File.separator + filename));
            } catch (IOException e) {
                e.printStackTrace();
            }
            //保存用于前端显示的picUrl
            String picUrl = filename;
            books.setCover(picUrl);
        }
        System.out.println(books);
        bookService.bookinsert(books);
        return "redirect:/checkall";
    }

//    删除图书
    @GetMapping("/deteles/{id}")
    public String Godelete(@PathVariable("id") int id){
        bookService.bookdelete(id);
        return "redirect:/checkall";
    }

//    按id搜索到图书然后去修改页面
    @GetMapping("/updete/{id}")
    public String toupdete(@PathVariable("id") int id,Model model){
        booklist bookupdet = bookService.Toupdete(id);
        Collection<booklist> booklists = bookService.bookselShow();
        model.addAttribute("Tobookupdet",bookupdet);
        return "views/toupdet/updateAddto";
    }

    //修改图书信息
    @PostMapping("/toupdet")
    public String bookupdate(@RequestParam("file") MultipartFile file,Model model){
        booklist booklist1 = new booklist();

        String filename = file.getOriginalFilename();
        //选择上传本地文件，picture中picUrl='',需要将文件地址插入picUrl
        if (!"".equals(filename)){
            // 定义上传文件保存路径
            //String path = "F:\\java\\workspace\\spring-boot-04-web-restfulcrud\\src\\main\\resources\\static\\asserts\\img";
            String path = filePath;
            // 新建文件
            File filepath = new File(path, filename);
            // 判断路径是否存在，如果不存在就创建一个
            if (!filepath.getParentFile().exists()) {
                filepath.getParentFile().mkdirs();
            }
            try {
                // 写入文件
                file.transferTo(new File(path + File.separator + filename));
            } catch (IOException e) {
                e.printStackTrace();
            }
            //保存用于前端显示的picUrl
            //String picUrl = "http://localhost:8081/seller/asserts/img/" + filename;
            String picUrl = "/bookcover/"+filename;
            booklist1.setCover(picUrl);
        }
        int bookupdate = bookService.bookupdate(booklist1);
        return "redirect:/checkall";
    }

}
