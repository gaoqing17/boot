package com.gaoqing;

import com.gaoqing.pojo.Dorrow;
import com.gaoqing.service.DorrowService;
import io.swagger.annotations.ApiModel;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.List;

@SpringBootTest
class LibrarysystemApplicationTests {
    @Autowired
    DorrowService dorrowService;
    @Test
    void contextLoads() throws SQLException {
        List<Dorrow> dorrows = dorrowService.FocusSelect();
        System.out.println(dorrows);
    }

}
